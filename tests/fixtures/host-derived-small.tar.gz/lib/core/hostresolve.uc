#!/usr/bin/env ucode
// Isolated fixture only: deterministic answers, no DNS queries or real cache writes.
function resolve_hosts(hosts) {
    let result = {};
    for (let host in hosts)
        result[host] = [ "203.0.113.8" ];
    return result;
}
return { resolve_hosts };
