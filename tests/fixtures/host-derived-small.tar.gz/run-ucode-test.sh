#!/bin/sh
# Synthetic fixture; does not modify UCI, nftables, services, or working rules.
set -eu
umask 077
base=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
work=$(mktemp -d /tmp/artak-host-route.XXXXXX)
[ -d /tmp/artak-routing-fixture/lib ] || { echo 'FAIL: prior test fixture library missing'; exit 1; }
cp -R /tmp/artak-routing-fixture/lib "$work/lib"
cp "$base/lib/xray/generator.uc" "$work/lib/xray/generator.uc"
cp "$base/lib/core/hostresolve.uc" "$work/lib/core/hostresolve.uc"
mkdir -p "$work/run" "$work/cache" "$work/stage" "$work/subscriptions"
export FORKOP_UCI_STATE_FILE="$work/state"
export FORKOP_RUNTIME_STATE_DIR="$work/run"
export FORKOP_SECTION_CACHE_DIR="$work/section-cache"
export FORKOP_PERSISTENT_SUBSCRIPTION_CACHE_DIR="$work/subscriptions"
export FORKOP_XRAY_LIST_CACHE_DIR="$work/cache"
export FORKOP_XRAY_STAGE_DIR="$work/stage"
export TMP_SUBSCRIPTION_FOLDER="$work/subscriptions"
cat > "$work/state" <<'EOF'
forkop.settings=settings
forkop.settings.routing_engine=xray
forkop.settings.dns_server=1.1.1.1
forkop.settings.bootstrap_dns_server=1.1.1.1
forkop.first=section
forkop.first.enabled=1
forkop.first.action=bypass
forkop.first.domain=a.test
forkop.second=section
forkop.second.enabled=1
forkop.second.action=block
forkop.second.domain=b.test
EOF
ucode -c -o /dev/null "$work/lib/xray/generator.uc"
ucode -L "$work/lib" "$work/lib/xray/generator.uc" generate-config "$work/config.json" "$work/ports.json" > "$work/generate.log"
ucode -e '
let f=require("fs");let j=json(f.readfile(ARGV[0]));let d=-1;let ip=-1;let fake=-1;let i=0;
for(let r in j.routing.rules||[]){
 if(index(r.inboundTag||[],"tproxy-in")<0){i++;continue;}
 for(let x in r.domain||[]) if(x=="full:b.test"||x=="domain:b.test") d=i;
 for(let x in r.ip||[]) {if(x=="203.0.113.8" && r.outboundTag=="direct" && ip<0) ip=i; if(x=="198.18.0.0/15" && r.outboundTag=="block") fake=i;}
 i++;
}
print(sprintf("Domain B index: %d; A resolved IP index: %d; FakeIP block index: %d\n",d,ip,fake));
if(d<0 || ip<0 || d>=ip || fake<0) exit(1);
' "$work/config.json"
if [ -x /tmp/artak-ucode-check/xray-arm64 ]; then
  /tmp/artak-ucode-check/xray-arm64 run -test -config "$work/config.json" >"$work/xray.log" 2>&1 || { echo 'FAIL: Xray rejected config'; exit 1; }
  echo 'PASS: Xray accepted synthetic configuration'
else
  echo 'SKIP: isolated Xray binary absent'
fi
echo 'PASS: real ucode generated later domain before earlier resolved IP'
